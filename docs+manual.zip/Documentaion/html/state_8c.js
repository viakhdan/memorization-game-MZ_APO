var state_8c =
[
    [ "fb", "state_8c.html#a29cf45bbde1c12a928fc01f19b547075", null ],
    [ "guesses", "state_8c.html#ab6bf6fa4b0ea3be981515bc0634b6ffe", null ],
    [ "round_scores", "state_8c.html#abe2553cf0756e636530e1a4be815b481", null ],
    [ "targets", "state_8c.html#a537b7e4d93c403574031011aa3fead3d", null ]
];