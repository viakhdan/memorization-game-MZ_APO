var structfigure__t =
[
    [ "color_idx", "structfigure__t.html#a8bf5aef11e4b30b7b922216c04a9b975", null ],
    [ "shape", "structfigure__t.html#a3411717f8b5742ace72e78067c060c06", null ],
    [ "y", "structfigure__t.html#ad78acf0fa1be34df469032d7025cb949", null ]
];