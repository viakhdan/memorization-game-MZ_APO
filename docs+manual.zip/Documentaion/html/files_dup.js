var files_dup =
[
    [ "config.c", "config_8c.html", "config_8c" ],
    [ "font_types.h", "font__types_8h_source.html", null ],
    [ "game.c", "game_8c.html", "game_8c" ],
    [ "graphics.c", "graphics_8c.html", "graphics_8c" ],
    [ "lcd.c", "lcd_8c.html", "lcd_8c" ],
    [ "leds.c", "leds_8c.html", "leds_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "memgame.h", "memgame_8h.html", "memgame_8h" ],
    [ "mzapo_parlcd.h", "mzapo__parlcd_8h_source.html", null ],
    [ "mzapo_phys.h", "mzapo__phys_8h_source.html", null ],
    [ "mzapo_regs.h", "mzapo__regs_8h_source.html", null ],
    [ "render.c", "render_8c.html", "render_8c" ],
    [ "serialize_lock.h", "serialize__lock_8h_source.html", null ],
    [ "state.c", "state_8c.html", "state_8c" ],
    [ "text.c", "text_8c.html", "text_8c" ]
];