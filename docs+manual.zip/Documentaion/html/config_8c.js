var config_8c =
[
    [ "difficulties", "config_8c.html#a5dde94645fa5545ae2037f587badab18", null ],
    [ "led_palette", "config_8c.html#a3df72693f41a7c161b1d3bed0e7e86ce", null ],
    [ "palette", "config_8c.html#a4f94d961c4093886f2843163b9f70e11", null ]
];