var structdifficulty__t =
[
    [ "hint16", "structdifficulty__t.html#ae612ed732122773079e7ad55d060ff93", null ],
    [ "hint24", "structdifficulty__t.html#ae4293a5afaa9d6362d584ec1e0328c01", null ],
    [ "n_figs", "structdifficulty__t.html#aa2325f4831f9f6c913ccb1abfa7a0fb3", null ],
    [ "show_ms", "structdifficulty__t.html#a5cce060571d505116a72006049409d3c", null ]
];