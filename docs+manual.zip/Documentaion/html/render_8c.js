var render_8c =
[
    [ "render_menu", "render_8c.html#a75f28a647fb5a7e34b4d5aaca831f0d8", null ],
    [ "render_place", "render_8c.html#a0d42dd4a2cbc3e6a01fab34f7c7b6da0", null ],
    [ "render_select", "render_8c.html#a185f942a8e6bf36daddff7f9823a4f27", null ],
    [ "render_show", "render_8c.html#aee0bfdd35b1b57d45fd2cfeed1418021", null ],
    [ "render_total", "render_8c.html#ad0354deeec171d48e8b7cc8d3f1aa3c7", null ]
];