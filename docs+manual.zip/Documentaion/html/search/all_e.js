var searchData=
[
  ['screen_5fh_0',['SCREEN_H',['../memgame_8h.html#a27cddfd509d28b4b2b0b44c093fac090',1,'memgame.h']]],
  ['screen_5fw_1',['SCREEN_W',['../memgame_8h.html#a9b6bc9242882d1e758e06ed751a2e8ec',1,'memgame.h']]],
  ['set_5fled_5fline_2',['set_led_line',['../leds_8c.html#a37fc1be344e5a5ca4a3ff5832aa72255',1,'set_led_line(unsigned char *mem_base, uint32_t v):&#160;leds.c'],['../memgame_8h.html#a37fc1be344e5a5ca4a3ff5832aa72255',1,'set_led_line(unsigned char *mem_base, uint32_t v):&#160;leds.c']]],
  ['set_5frgb_5fleds_3',['set_rgb_leds',['../leds_8c.html#a2090be2acc63e23eeba17e46423e4242',1,'set_rgb_leds(unsigned char *mem_base, uint32_t rgb24):&#160;leds.c'],['../memgame_8h.html#a2090be2acc63e23eeba17e46423e4242',1,'set_rgb_leds(unsigned char *mem_base, uint32_t rgb24):&#160;leds.c']]],
  ['shape_4',['shape',['../structfigure__t.html#a3411717f8b5742ace72e78067c060c06',1,'figure_t']]],
  ['show_5fled_5fbar_5',['show_led_bar',['../leds_8c.html#ab7620994ac2cecb5494630f2351e8dcc',1,'show_led_bar(unsigned char *mem_base, int n):&#160;leds.c'],['../memgame_8h.html#ab7620994ac2cecb5494630f2351e8dcc',1,'show_led_bar(unsigned char *mem_base, int n):&#160;leds.c']]],
  ['show_5fms_6',['show_ms',['../structdifficulty__t.html#a5cce060571d505116a72006049409d3c',1,'difficulty_t']]],
  ['state_2ec_7',['state.c',['../state_8c.html',1,'']]]
];
