var searchData=
[
  ['knob_5fticks_5fper_5fstep_0',['KNOB_TICKS_PER_STEP',['../memgame_8h.html#a3e85c38d646290d76fdcdffe51a807e3',1,'memgame.h']]]
];
