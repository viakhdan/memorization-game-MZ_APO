var searchData=
[
  ['clear_5fscreen_0',['clear_screen',['../graphics_8c.html#ae5effa5d68476cc773fa42d467e1361e',1,'clear_screen(uint16_t c):&#160;graphics.c'],['../memgame_8h.html#ae5effa5d68476cc773fa42d467e1361e',1,'clear_screen(uint16_t c):&#160;graphics.c']]],
  ['color_5fidx_1',['color_idx',['../structfigure__t.html#a8bf5aef11e4b30b7b922216c04a9b975',1,'figure_t']]],
  ['config_2ec_2',['config.c',['../config_8c.html',1,'']]]
];
