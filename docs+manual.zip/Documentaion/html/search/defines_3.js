var searchData=
[
  ['pts_5fcombo_0',['PTS_COMBO',['../memgame_8h.html#aaf53dce8e1b7f215cee49c5c754917e1',1,'memgame.h']]],
  ['pts_5fper_5ffig_1',['PTS_PER_FIG',['../memgame_8h.html#a5de1bb833463d89056772d3ec20ae520',1,'memgame.h']]]
];
