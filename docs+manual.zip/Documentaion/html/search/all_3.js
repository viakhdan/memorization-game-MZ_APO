var searchData=
[
  ['elapsed_5fms_0',['elapsed_ms',['../game_8c.html#af826f1ae27154ef6a6d0696b3a0b2462',1,'elapsed_ms(const struct timespec *start):&#160;game.c'],['../memgame_8h.html#af826f1ae27154ef6a6d0696b3a0b2462',1,'elapsed_ms(const struct timespec *start):&#160;game.c']]]
];
