var searchData=
[
  ['shape_0',['shape',['../structfigure__t.html#a3411717f8b5742ace72e78067c060c06',1,'figure_t']]],
  ['show_5fms_1',['show_ms',['../structdifficulty__t.html#a5cce060571d505116a72006049409d3c',1,'difficulty_t']]]
];
