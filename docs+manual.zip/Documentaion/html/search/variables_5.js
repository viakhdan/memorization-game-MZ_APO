var searchData=
[
  ['led_5fpalette_0',['led_palette',['../config_8c.html#a3df72693f41a7c161b1d3bed0e7e86ce',1,'led_palette:&#160;config.c'],['../memgame_8h.html#a3df72693f41a7c161b1d3bed0e7e86ce',1,'led_palette:&#160;config.c']]]
];
