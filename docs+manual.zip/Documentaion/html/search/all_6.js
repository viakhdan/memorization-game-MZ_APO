var searchData=
[
  ['hint16_0',['hint16',['../structdifficulty__t.html#ae612ed732122773079e7ad55d060ff93',1,'difficulty_t']]],
  ['hint24_1',['hint24',['../structdifficulty__t.html#ae4293a5afaa9d6362d584ec1e0328c01',1,'difficulty_t']]]
];
