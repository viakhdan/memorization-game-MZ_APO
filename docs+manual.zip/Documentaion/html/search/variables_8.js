var searchData=
[
  ['round_5fscores_0',['round_scores',['../memgame_8h.html#abe2553cf0756e636530e1a4be815b481',1,'round_scores:&#160;state.c'],['../state_8c.html#abe2553cf0756e636530e1a4be815b481',1,'round_scores:&#160;state.c']]]
];
