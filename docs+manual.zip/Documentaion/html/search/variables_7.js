var searchData=
[
  ['palette_0',['palette',['../config_8c.html#a4f94d961c4093886f2843163b9f70e11',1,'palette:&#160;config.c'],['../memgame_8h.html#a4f94d961c4093886f2843163b9f70e11',1,'palette:&#160;config.c']]]
];
