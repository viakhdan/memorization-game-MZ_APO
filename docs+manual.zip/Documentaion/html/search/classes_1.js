var searchData=
[
  ['figure_5ft_0',['figure_t',['../structfigure__t.html',1,'']]],
  ['font_5fdescriptor_5ft_1',['font_descriptor_t',['../structfont__descriptor__t.html',1,'']]]
];
