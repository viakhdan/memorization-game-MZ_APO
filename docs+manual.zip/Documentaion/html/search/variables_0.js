var searchData=
[
  ['color_5fidx_0',['color_idx',['../structfigure__t.html#a8bf5aef11e4b30b7b922216c04a9b975',1,'figure_t']]]
];
