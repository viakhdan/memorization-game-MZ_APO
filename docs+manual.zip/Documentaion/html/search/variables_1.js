var searchData=
[
  ['difficulties_0',['difficulties',['../config_8c.html#a5dde94645fa5545ae2037f587badab18',1,'difficulties:&#160;config.c'],['../memgame_8h.html#a5dde94645fa5545ae2037f587badab18',1,'difficulties:&#160;config.c']]]
];
