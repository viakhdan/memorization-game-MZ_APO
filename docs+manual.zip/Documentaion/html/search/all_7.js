var searchData=
[
  ['isqrt_5fi_0',['isqrt_i',['../graphics_8c.html#aacd0ad9190a30bcc3257b4621a00829f',1,'isqrt_i(int n):&#160;graphics.c'],['../memgame_8h.html#aacd0ad9190a30bcc3257b4621a00829f',1,'isqrt_i(int n):&#160;graphics.c']]]
];
