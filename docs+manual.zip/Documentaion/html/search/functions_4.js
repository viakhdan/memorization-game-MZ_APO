var searchData=
[
  ['generate_5ftargets_0',['generate_targets',['../game_8c.html#a6116bc7848409128225c627778eab0f9',1,'generate_targets(int n_figs):&#160;game.c'],['../memgame_8h.html#a6116bc7848409128225c627778eab0f9',1,'generate_targets(int n_figs):&#160;game.c']]]
];
