var searchData=
[
  ['palette_0',['palette',['../config_8c.html#a4f94d961c4093886f2843163b9f70e11',1,'palette:&#160;config.c'],['../memgame_8h.html#a4f94d961c4093886f2843163b9f70e11',1,'palette:&#160;config.c']]],
  ['pts_5fcombo_1',['PTS_COMBO',['../memgame_8h.html#aaf53dce8e1b7f215cee49c5c754917e1',1,'memgame.h']]],
  ['pts_5fper_5ffig_2',['PTS_PER_FIG',['../memgame_8h.html#a5de1bb833463d89056772d3ec20ae520',1,'memgame.h']]]
];
