var indexSectionsWithContent =
{
  0: "bcdefghiklmnprsty",
  1: "df",
  2: "cglmrst",
  3: "cdefgilmrs",
  4: "cdfghlnprsty",
  5: "bfkps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

