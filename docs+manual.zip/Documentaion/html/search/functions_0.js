var searchData=
[
  ['clear_5fscreen_0',['clear_screen',['../graphics_8c.html#ae5effa5d68476cc773fa42d467e1361e',1,'clear_screen(uint16_t c):&#160;graphics.c'],['../memgame_8h.html#ae5effa5d68476cc773fa42d467e1361e',1,'clear_screen(uint16_t c):&#160;graphics.c']]]
];
