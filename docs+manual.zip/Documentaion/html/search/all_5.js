var searchData=
[
  ['game_2ec_0',['game.c',['../game_8c.html',1,'']]],
  ['generate_5ftargets_1',['generate_targets',['../game_8c.html#a6116bc7848409128225c627778eab0f9',1,'generate_targets(int n_figs):&#160;game.c'],['../memgame_8h.html#a6116bc7848409128225c627778eab0f9',1,'generate_targets(int n_figs):&#160;game.c']]],
  ['graphics_2ec_2',['graphics.c',['../graphics_8c.html',1,'']]],
  ['guesses_3',['guesses',['../memgame_8h.html#ab6bf6fa4b0ea3be981515bc0634b6ffe',1,'guesses:&#160;state.c'],['../state_8c.html#ab6bf6fa4b0ea3be981515bc0634b6ffe',1,'guesses:&#160;state.c']]]
];
