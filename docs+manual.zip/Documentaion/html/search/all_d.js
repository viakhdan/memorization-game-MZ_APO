var searchData=
[
  ['render_2ec_0',['render.c',['../render_8c.html',1,'']]],
  ['render_5fmenu_1',['render_menu',['../memgame_8h.html#a75f28a647fb5a7e34b4d5aaca831f0d8',1,'render_menu(int diff_idx):&#160;render.c'],['../render_8c.html#a75f28a647fb5a7e34b4d5aaca831f0d8',1,'render_menu(int diff_idx):&#160;render.c']]],
  ['render_5fplace_2',['render_place',['../memgame_8h.html#a0d42dd4a2cbc3e6a01fab34f7c7b6da0',1,'render_place(int shape, int color_idx, int cx, int cy, int placed, int n_figs, int round_idx):&#160;render.c'],['../render_8c.html#a0d42dd4a2cbc3e6a01fab34f7c7b6da0',1,'render_place(int shape, int color_idx, int cx, int cy, int placed, int n_figs, int round_idx):&#160;render.c']]],
  ['render_5fselect_3',['render_select',['../memgame_8h.html#a185f942a8e6bf36daddff7f9823a4f27',1,'render_select(int shape_idx, int color_idx, int placed, int n_figs, int round_idx):&#160;render.c'],['../render_8c.html#a185f942a8e6bf36daddff7f9823a4f27',1,'render_select(int shape_idx, int color_idx, int placed, int n_figs, int round_idx):&#160;render.c']]],
  ['render_5fshow_4',['render_show',['../memgame_8h.html#aee0bfdd35b1b57d45fd2cfeed1418021',1,'render_show(int ms_left, int total_show_ms, int n_figs, int round_idx):&#160;render.c'],['../render_8c.html#aee0bfdd35b1b57d45fd2cfeed1418021',1,'render_show(int ms_left, int total_show_ms, int n_figs, int round_idx):&#160;render.c']]],
  ['render_5ftotal_5',['render_total',['../memgame_8h.html#ad0354deeec171d48e8b7cc8d3f1aa3c7',1,'render_total(int total, int max_total, int diff):&#160;render.c'],['../render_8c.html#ad0354deeec171d48e8b7cc8d3f1aa3c7',1,'render_total(int total, int max_total, int diff):&#160;render.c']]],
  ['round_5fscore_6',['round_score',['../game_8c.html#abbc6fd0580e0b72aefc52afac84ac156',1,'round_score(int n_figs):&#160;game.c'],['../memgame_8h.html#abbc6fd0580e0b72aefc52afac84ac156',1,'round_score(int n_figs):&#160;game.c']]],
  ['round_5fscores_7',['round_scores',['../memgame_8h.html#abe2553cf0756e636530e1a4be815b481',1,'round_scores:&#160;state.c'],['../state_8c.html#abe2553cf0756e636530e1a4be815b481',1,'round_scores:&#160;state.c']]]
];
