var searchData=
[
  ['targets_0',['targets',['../memgame_8h.html#a537b7e4d93c403574031011aa3fead3d',1,'targets:&#160;state.c'],['../state_8c.html#a537b7e4d93c403574031011aa3fead3d',1,'targets:&#160;state.c']]]
];
