var searchData=
[
  ['guesses_0',['guesses',['../memgame_8h.html#ab6bf6fa4b0ea3be981515bc0634b6ffe',1,'guesses:&#160;state.c'],['../state_8c.html#ab6bf6fa4b0ea3be981515bc0634b6ffe',1,'guesses:&#160;state.c']]]
];
