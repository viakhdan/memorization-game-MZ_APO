var searchData=
[
  ['n_5ffigs_0',['n_figs',['../structdifficulty__t.html#aa2325f4831f9f6c913ccb1abfa7a0fb3',1,'difficulty_t']]]
];
