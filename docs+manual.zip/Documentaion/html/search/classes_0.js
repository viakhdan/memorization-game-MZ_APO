var searchData=
[
  ['difficulty_5ft_0',['difficulty_t',['../structdifficulty__t.html',1,'']]]
];
