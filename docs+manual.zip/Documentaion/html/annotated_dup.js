var annotated_dup =
[
    [ "difficulty_t", "structdifficulty__t.html", "structdifficulty__t" ],
    [ "figure_t", "structfigure__t.html", "structfigure__t" ],
    [ "font_descriptor_t", "structfont__descriptor__t.html", null ]
];