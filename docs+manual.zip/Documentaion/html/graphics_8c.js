var graphics_8c =
[
    [ "clear_screen", "graphics_8c.html#ae5effa5d68476cc773fa42d467e1361e", null ],
    [ "draw_circle", "graphics_8c.html#afb1790fb177d207e6dc1de40bd1eabe7", null ],
    [ "draw_crosshair", "graphics_8c.html#ac72e68b032ecc3a4549783d79047b223", null ],
    [ "draw_rect_outline", "graphics_8c.html#a427caf16b10a0b8faa1b323a1ba956ab", null ],
    [ "draw_shape", "graphics_8c.html#a3ecdbe777f5fb72ad28b917e66caa3ea", null ],
    [ "draw_square", "graphics_8c.html#a39261e4b2dd85952361d77a38fa1c7a8", null ],
    [ "draw_triangle", "graphics_8c.html#a89992b248aeca584eb26467c5da7dfad", null ],
    [ "fill_rect", "graphics_8c.html#a8e6f906193dbb2d9561485a1d673ba54", null ],
    [ "isqrt_i", "graphics_8c.html#aacd0ad9190a30bcc3257b4621a00829f", null ]
];