var game_8c =
[
    [ "elapsed_ms", "game_8c.html#af826f1ae27154ef6a6d0696b3a0b2462", null ],
    [ "generate_targets", "game_8c.html#a6116bc7848409128225c627778eab0f9", null ],
    [ "round_score", "game_8c.html#abbc6fd0580e0b72aefc52afac84ac156", null ]
];